package com.eteration.simplebanking.services;


// This class is a place holder you can change the complete implementation
public class AccountService {

}
