package com.eteration.simplebanking.controller;

// This class is a place holder you can change the complete implementation
public class AccountController {


    public Object getAccount() {
        return null;
    }

    public Object credit( ) {
        return null;
    }
    public Object debit() {
        return null;
	}
}